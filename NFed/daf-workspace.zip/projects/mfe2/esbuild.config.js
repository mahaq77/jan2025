const {
  withNativeFederation,
  shareAll,
} = require("@angular-architects/native-federation/config");

module.exports = withNativeFederation({
  name: "mfe2",
  filename: "remoteEntry.js",
  exposes: {
    "./Module": "./projects/mfe2/src/app/mfe2/mfe2.module.ts", // Expose the module
  },
  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: "auto",
    }),
  },
});
