const {
  withNativeFederation,
  shareAll,
} = require("@angular-architects/native-federation/config");

module.exports = withNativeFederation({
  name: "mfe1",
  filename: "remoteEntry.js",
  exposes: {
    "./Module": "./projects/mfe1/src/app/mfe1/mfe1.module.ts", // Expose the module
  },
  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: "auto",
    }),
  },
});
