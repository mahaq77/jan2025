const {
  withNativeFederation,
  shareAll,
} = require("@angular-architects/native-federation/config");
