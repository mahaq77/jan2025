import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';

export const routes: Routes = [
  {
    path: 'mfe1',
    loadChildren: () =>
      loadRemoteModule({
        remoteEntry: 'http://localhost:4201/remoteEntry.js', // URL of the remote entry
        remoteName: 'mfe1',
        exposedModule: './Module',
      }).then((m) => m.Mfe1Module),
  },
  {
    path: 'mfe2',
    loadChildren: () =>
      loadRemoteModule({
        remoteEntry: 'http://localhost:4202/remoteEntry.js', // URL of the remote entry
        remoteName: 'mfe2',
        exposedModule: './Module',
      }).then((m) => m.Mfe2Module),
  },
  { path: '', redirectTo: '/home', pathMatch: 'full' }, // Default route
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
  })
  export class AppRoutingModule {}
